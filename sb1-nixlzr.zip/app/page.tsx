"use client";

import { useState, useEffect } from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import OrderForm from '@/components/OrderForm';
import ThankYou from '@/components/ThankYou';

export default function Home() {
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    address: '',
    phone: '',
    product: '',
    memory: '',
    ram: '',
    brand: '',
    color: '',
    priceRange: '',
    paymentMethod: '',
  });

  useEffect(() => {
    const savedFormData = localStorage.getItem('orderFormData');
    if (savedFormData) {
      setFormData(JSON.parse(savedFormData));
    }
  }, []);

  const handleFormSubmit = async (data: typeof formData) => {
    setFormData(data);
    localStorage.setItem('orderFormData', JSON.stringify(data));
    setIsSubmitted(true);

    // Send email to client
    try {
      const response = await fetch('/api/send-email', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        throw new Error('Failed to send email');
      }
    } catch (error) {
      console.error('Error sending email:', error);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-gray-900 via-black to-gray-900 text-white">
      <Header />
      <main className="flex-grow container mx-auto px-4 py-12">
        {!isSubmitted ? (
          <OrderForm onSubmit={handleFormSubmit} initialData={formData} />
        ) : (
          <ThankYou formData={formData} />
        )}
      </main>
      <Footer />
    </div>
  );
}